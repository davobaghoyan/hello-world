﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace copyarray
{
    class Program
    {
        static void Main(string[] args)
        {
            double[] myarrray = new double[5] { 201.2, 3.5, 4.8, 6.3, 9.1 };
            
            int[] result = Copyarray(myarrray, 5);
            for (int i = 0; i < 5; i++)
                Console.WriteLine(result[i]);
            Console.ReadLine();
        }



        static int[] Copyarray(double[] myarray, int size)
        {

            int[] copiedarray = new int[size];
            for (int i = 0; i < size; i++)
            {
                copiedarray[i] = Convert.ToInt32(myarray[i]);
            }
            return copiedarray;

        }

    }
    C:\Users\Davit\source\repos\ConsoleApp7\ConsoleApp7\
}
